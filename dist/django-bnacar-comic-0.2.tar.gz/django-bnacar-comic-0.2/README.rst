=====
Comic
=====

This is a Django app I threw together to host a comic series. It's pretty
bare-bones.

Add "comic" to INSTALLED_APPS and path('whateveryouwant/', include('comic.urls')) to your site's urls.py
